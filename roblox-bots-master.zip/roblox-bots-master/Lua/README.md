ROBLOX scripts that help you use the bots.
