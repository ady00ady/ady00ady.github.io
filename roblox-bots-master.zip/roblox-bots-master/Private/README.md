This is part of an example and only provides compatibility with existing functions.
